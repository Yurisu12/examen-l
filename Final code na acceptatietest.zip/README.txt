Ik heb de code aangepast na de acceptatie test. alles werkt nu naar behoren :)
alleen bon is er niet.

Reserveren deed het 10-11 ana het einde van de dag niet...oorzaak..geen idee...ik heb het kopje allergieën gewoon weg gehaald en toen werkte alles weer dus geen idee :)